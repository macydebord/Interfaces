import java.awt.Rectangle;
import java.util.ArrayList;

public class BigRectLister {
    public static void main(String[] args) {
        ArrayList<Rectangle> rectangles = createRectangles();
        Filter bigRectangleFilter = new BigRectangleFilter();
        ArrayList<Rectangle> bigRectangles = collectAll(rectangles, bigRectangleFilter);
        System.out.println("Big Rectangles:");
        for (Rectangle rect : bigRectangles) {
            System.out.println("Width: " + rect.getWidth() + ", Height: " + rect.getHeight());
        }
    }

    private static ArrayList<Rectangle> createRectangles() {
        ArrayList<Rectangle> rectangles = new ArrayList<>();
        rectangles.add(new Rectangle(2, 5));   // 10
        rectangles.add(new Rectangle(6, 2));   // 12
        rectangles.add(new Rectangle(2, 7));   // 14
        rectangles.add(new Rectangle(4, 1));   // 4
        rectangles.add(new Rectangle(5, 4));   // 20
        rectangles.add(new Rectangle(2, 2));   // 8
        rectangles.add(new Rectangle(2, 1));   // 2
        rectangles.add(new Rectangle(1, 1));   // 1
        rectangles.add(new Rectangle(3, 2));   // 6
        rectangles.add(new Rectangle(3, 5));   // 15
        return rectangles;
    }

    private static ArrayList<Rectangle> collectAll(ArrayList<Rectangle> objects, Filter filter) {
        ArrayList<Rectangle> result = new ArrayList<>();
        for (Rectangle obj : objects) {
            if (filter.accept(obj)) {
                result.add(obj);
            }
        }
        return result;
    }
}

