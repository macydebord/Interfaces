import javax.swing.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class ShortLister
{
    public static void main(String[] args)
    {
        ArrayList<String> words = readWordsFromFile();
        Filter shortWordFilter = new ShortWordFilter();
        ArrayList<String> shortWords = collectAll(words, shortWordFilter);
        System.out.println("Short Words:");
        for (String word : shortWords)
        {
            System.out.println(word);
        }
    }

    private static ArrayList<String> readWordsFromFile()
    {
        ArrayList<String> words = new ArrayList<>();
        JFileChooser fileChooser = new JFileChooser();
        int returnValue = fileChooser.showOpenDialog(null);

        if (returnValue == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            try (Scanner scanner = new Scanner(selectedFile)) {
                while (scanner.hasNext()) {
                    String word = scanner.next();
                    // was printing cf0 for some reason (probably because of file), getting rid of it
                    word = word.replaceAll("cf0", "");
                    words.add(word);
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
        return words;
    }

    private static ArrayList<String> collectAll(ArrayList<String> objects, Filter filter) {
        ArrayList<String> result = new ArrayList<>();
        for (String obj : objects) {
            if (filter.accept(obj)) {
                result.add(obj);
            }
        }
        return result;
    }
}
