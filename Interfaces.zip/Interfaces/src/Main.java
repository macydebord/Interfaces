import java.util.ArrayList;

public class Main
{
    public static void main(String[] args)
    {
        ArrayList<Object> objects = new ArrayList<>();
    }

    public static <T> ArrayList<T> collectAll(ArrayList<T> objects, Filter filter)
    {
        ArrayList<T> result = new ArrayList<>();
        for (T obj : objects)
        {
            if (filter.accept(obj))
            {
                result.add(obj);
            }
        }
        return result;
    }
}

